package com.example.kalladai_borewell
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
