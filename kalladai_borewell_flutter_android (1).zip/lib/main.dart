import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.load();
  runApp(BorewellApp(store: store));
}

class BorewellApp extends StatelessWidget {
  final AppStore store;
  const BorewellApp({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kalladai Borewell',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xfff7f8fc),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
          filled: true,
        ),
      ),
      home: HomePage(store: store),
    );
  }
}

class AppStore extends ChangeNotifier {
  Map<String, dynamic> project = {};
  Map<String, List<Item>> lists = {};
  bool loaded = false;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('app_data');
    if (raw != null) {
      _fromJson(jsonDecode(raw));
    } else {
      final initial = jsonDecode(await rootBundle.loadString('assets/initial_data.json'));
      _fromJson(initial);
      await _save();
    }
    loaded = true;
  }

  void _fromJson(Map<String, dynamic> d) {
    project = Map<String, dynamic>.from(d['project'] ?? {});
    lists = {};
    for (final key in ['estimate','ebMaterials','pvcMaterials','subEstimate']) {
      lists[key] = ((d[key] ?? []) as List)
          .map((e) => Item.fromJson(Map<String,dynamic>.from(e)))
          .toList();
    }
  }

  Map<String,dynamic> _toJson() => {
    'project': project,
    for (final e in lists.entries) e.key: e.value.map((x)=>x.toJson()).toList(),
  };

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('app_data', jsonEncode(_toJson()));
  }

  Future<void> addItem(String key, Item item) async {
    lists[key] ??= [];
    lists[key]!.add(item);
    await _save(); notifyListeners();
  }

  Future<void> updateItem(String key, int index, Item item) async {
    lists[key]![index] = item;
    await _save(); notifyListeners();
  }

  Future<void> deleteItem(String key, int index) async {
    lists[key]!.removeAt(index);
    await _save(); notifyListeners();
  }

  Future<void> resetToExcel() async {
    final initial = jsonDecode(await rootBundle.loadString('assets/initial_data.json'));
    _fromJson(initial); await _save(); notifyListeners();
  }

  double total(String key) =>
      (lists[key] ?? []).fold(0.0, (s, i) => s + i.amount);

  double totalAllEstimate() => total('estimate');
  double totalMaterials() => total('ebMaterials') + total('pvcMaterials');
}

class Item {
  int? sno;
  double qty;
  String unit;
  String description;
  double rate;
  double amount;

  Item({
    this.sno,
    required this.qty,
    required this.unit,
    required this.description,
    required this.rate,
    double? amount,
  }) : amount = amount ?? qty * rate;

  Map<String,dynamic> toJson()=> {
    'sno': sno, 'qty': qty, 'unit': unit,
    'description': description, 'rate': rate, 'amount': amount
  };

  factory Item.fromJson(Map<String,dynamic> j)=>Item(
    sno: (j['sno'] as num?)?.toInt(),
    qty: (j['qty'] as num?)?.toDouble() ?? 0,
    unit: j['unit']?.toString() ?? '',
    description: j['description']?.toString() ?? '',
    rate: (j['rate'] as num?)?.toDouble() ?? 0,
    amount: (j['amount'] as num?)?.toDouble(),
  );
}

String money(double v) => '₹${v.toStringAsFixed(0)}';

class HomePage extends StatefulWidget {
  final AppStore store;
  const HomePage({super.key, required this.store});
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage> {
  int index=0;
  late final pages=[
    Dashboard(store: widget.store),
    EstimatePage(store: widget.store, listKey:'estimate', title:'Detailed Estimate'),
    EstimatePage(store: widget.store, listKey:'ebMaterials', title:'EB Materials'),
    EstimatePage(store: widget.store, listKey:'pvcMaterials', title:'PVC & GI Materials'),
    EstimatePage(store: widget.store, listKey:'subEstimate', title:'Sub Estimate'),
    ReportsPage(store: widget.store),
  ];
  @override Widget build(BuildContext context)=>Scaffold(
    appBar: AppBar(
      title: const Text('Kalladai Borewell'),
      actions:[IconButton(
        tooltip:'Reset from Excel',
        onPressed:() async {
          final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(
            title:const Text('Reset data?'),
            content:const Text('This will replace your edits with the original Excel data.'),
            actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),
              FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Reset'))],
          ));
          if(ok==true) await widget.store.resetToExcel();
        }, icon:const Icon(Icons.restore))
      ]
    ),
    body: pages[index],
    bottomNavigationBar: NavigationBar(
      selectedIndex:index,
      onDestinationSelected:(i)=>setState(()=>index=i),
      destinations:const[
        NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'Dashboard'),
        NavigationDestination(icon:Icon(Icons.receipt_long_outlined),selectedIcon:Icon(Icons.receipt_long),label:'Estimate'),
        NavigationDestination(icon:Icon(Icons.electrical_services_outlined),label:'EB'),
        NavigationDestination(icon:Icon(Icons.plumbing_outlined),label:'PVC/GI'),
        NavigationDestination(icon:Icon(Icons.list_alt_outlined),label:'Sub'),
        NavigationDestination(icon:Icon(Icons.analytics_outlined),label:'Reports'),
      ],
    ),
  );
}

class Dashboard extends StatelessWidget {
  final AppStore store;
  const Dashboard({super.key,required this.store});
  @override Widget build(BuildContext context){
    final p=store.project;
    return AnimatedBuilder(animation:store,builder:(context,_){
      return ListView(padding:const EdgeInsets.all(16),children:[
        Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(
          crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('BOREWELL WORK',style:Theme.of(context).textTheme.labelLarge),
            const SizedBox(height:8),
            Text(p['name']?.toString()??'',style:Theme.of(context).textTheme.titleLarge),
            const SizedBox(height:12),
            Text('Contractor: ${p['contractor']??''}'),
            Text('Book No: ${p['bookNo']??''}   •   FY: ${p['financialYear']??''}'),
          ]))),
        const SizedBox(height:12),
        GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
          crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.55,children:[
            StatCard('Estimate',money(p['estimateAmount'] is num ? (p['estimateAmount'] as num).toDouble():store.totalAllEstimate()),Icons.account_balance_wallet),
            StatCard('Detailed total',money(store.totalAllEstimate()),Icons.calculate),
            StatCard('EB materials',money(store.total('ebMaterials')),Icons.electrical_services),
            StatCard('PVC/GI',money(store.total('pvcMaterials')),Icons.plumbing),
          ]),
        const SizedBox(height:12),
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('Quick summary',style:Theme.of(context).textTheme.titleMedium),
          const SizedBox(height:10),
          SummaryLine('Estimate items', '${store.lists['estimate']?.length??0}'),
          SummaryLine('EB material items', '${store.lists['ebMaterials']?.length??0}'),
          SummaryLine('PVC/GI material items', '${store.lists['pvcMaterials']?.length??0}'),
          SummaryLine('Sub-estimate items', '${store.lists['subEstimate']?.length??0}'),
        ]))),
      ]);
    });
  }
}
class StatCard extends StatelessWidget{
  final String title,value;final IconData icon;
  const StatCard(this.title,this.value,this.icon,{super.key});
  @override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon),const Spacer(),Text(title),Text(value,style:Theme.of(c).textTheme.titleLarge)])));
}
class SummaryLine extends StatelessWidget{
  final String a,b;const SummaryLine(this.a,this.b,{super.key});
  @override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(a),Text(b,style:const TextStyle(fontWeight:FontWeight.bold))]));
}

class EstimatePage extends StatefulWidget {
  final AppStore store; final String listKey,title;
  const EstimatePage({super.key,required this.store,required this.listKey,required this.title});
  @override State<EstimatePage> createState()=>_EstimatePageState();
}
class _EstimatePageState extends State<EstimatePage>{
  String search='';
  @override Widget build(BuildContext context)=>AnimatedBuilder(animation:widget.store,builder:(context,_){
    final all=widget.store.lists[widget.listKey]??[];
    final items=all.where((x)=>x.description.toLowerCase().contains(search.toLowerCase())).toList();
    return Scaffold(
      backgroundColor:Colors.transparent,
      body:Column(children:[
        Padding(padding:const EdgeInsets.fromLTRB(12,12,12,4),child:TextField(
          decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search description'),
          onChanged:(v)=>setState(()=>search=v),
        )),
        Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:6),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
          Text('${items.length} items'),Text(money(items.fold(0.0,(s,i)=>s+i.amount)),style:const TextStyle(fontWeight:FontWeight.bold)),
        ])),
        Expanded(child:ListView.builder(itemCount:items.length,itemBuilder:(c,i){
          final item=items[i]; final actual=all.indexOf(item);
          return Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:4),child:ListTile(
            leading:CircleAvatar(child:Text('${item.sno??actual+1}')),
            title:Text(item.description),
            subtitle:Text('${item.qty} ${item.unit}  ×  ${money(item.rate)}'),
            trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[
              Text(money(item.amount),style:const TextStyle(fontWeight:FontWeight.bold)),
              Row(mainAxisSize:MainAxisSize.min,children:[
                IconButton(icon:const Icon(Icons.edit,size:20),onPressed:()=>editItem(context,actual,item)),
                IconButton(icon:const Icon(Icons.delete_outline,size:20),onPressed:()=>widget.store.deleteItem(widget.listKey,actual)),
              ])
            ]),
          );
        })),
      ]),
      floatingActionButton:FloatingActionButton.extended(onPressed:()=>editItem(context,null,null),icon:const Icon(Icons.add),label:const Text('Add')),
    );
  });

  Future<void> editItem(BuildContext context,int? index,Item? item) async {
    final result=await showDialog<Item>(context:context,builder:(c)=>ItemDialog(item:item,nextSno:(widget.store.lists[widget.listKey]?.length??0)+1));
    if(result!=null){
      if(index==null) await widget.store.addItem(widget.listKey,result);
      else await widget.store.updateItem(widget.listKey,index,result);
    }
  }
}

class ItemDialog extends StatefulWidget{
  final Item? item;final int nextSno;
  const ItemDialog({super.key,this.item,required this.nextSno});
  @override State<ItemDialog> createState()=>_ItemDialogState();
}
class _ItemDialogState extends State<ItemDialog>{
  late TextEditingController sno,qty,unit,desc,rate;
  @override void initState(){super.initState();final x=widget.item;
    sno=TextEditingController(text:'${x?.sno??widget.nextSno}');
    qty=TextEditingController(text:'${x?.qty??1}');
    unit=TextEditingController(text:x?.unit??'No');
    desc=TextEditingController(text:x?.description??'');
    rate=TextEditingController(text:'${x?.rate??0}');
  }
  @override void dispose(){for(final c in[sno,qty,unit,desc,rate])c.dispose();super.dispose();}
  @override Widget build(BuildContext c)=>AlertDialog(
    title:Text(widget.item==null?'Add item':'Edit item'),
    content:SizedBox(width:500,child:SingleChildScrollView(child:Column(children:[
      Row(children:[Expanded(child:TextField(controller:sno,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'S.No'))),const SizedBox(width:8),Expanded(child:TextField(controller:qty,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Quantity')))]),
      const SizedBox(height:10),
      Row(children:[Expanded(child:TextField(controller:unit,decoration:const InputDecoration(labelText:'Unit'))),const SizedBox(width:8),Expanded(child:TextField(controller:rate,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Rate')))]),
      const SizedBox(height:10),
      TextField(controller:desc,maxLines:3,decoration:const InputDecoration(labelText:'Description')),
    ]))),
    actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Cancel')),FilledButton(onPressed:(){
      final q=double.tryParse(qty.text)??0,r=double.tryParse(rate.text)??0;
      Navigator.pop(c,Item(sno:int.tryParse(sno.text),qty:q,unit:unit.text,description:desc.text,rate:r));
    },child:const Text('Save'))],
  );
}

class ReportsPage extends StatelessWidget{
  final AppStore store;const ReportsPage({super.key,required this.store});
  @override Widget build(BuildContext context)=>AnimatedBuilder(animation:store,builder:(c,_){
    final estimate=store.total('estimate'), eb=store.total('ebMaterials'), pvc=store.total('pvcMaterials'), sub=store.total('subEstimate');
    return ListView(padding:const EdgeInsets.all(16),children:[
      Text('Reports',style:Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height:12),
      ReportCard('Comparative Statement','Original estimate vs execution can be entered from the item lists.',Icons.compare_arrows,[
        ['Original estimate',money(estimate)],['Material total',money(eb+pvc)],['Sub estimate',money(sub)]
      ]),
      ReportCard('Completion Report','Current calculated totals for the project.',Icons.task_alt,[
        ['Estimate total',money(estimate)],['Project sanctioned',money(store.project['estimateAmount'] is num ? (store.project['estimateAmount'] as num).toDouble():0)],
        ['Variance',money(estimate-(store.project['estimateAmount'] is num ? (store.project['estimateAmount'] as num).toDouble():0))]
      ]),
      const SizedBox(height:8),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Data',style:Theme.of(context).textTheme.titleMedium),
        const SizedBox(height:8),
        const Text('Edits are saved locally on this Android device using SharedPreferences. Use Reset on the top-right to restore the workbook’s initial data.')
      ])))
    ]);
  });
}
class ReportCard extends StatelessWidget{
  final String title,desc;final IconData icon;final List<List<String>> rows;
  const ReportCard(this.title,this.desc,this.icon,this.rows,{super.key});
  @override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Row(children:[Icon(icon),const SizedBox(width:10),Text(title,style:Theme.of(c).textTheme.titleMedium)]),
    const SizedBox(height:6),Text(desc),const Divider(),
    ...rows.map((r)=>SummaryLine(r[0],r[1]))
  ])));
}
