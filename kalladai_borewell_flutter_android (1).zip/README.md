# Kalladai Borewell – Flutter Android App

This project converts the supplied **Borewell at Kalladai.xlsx** workbook into a working Flutter Android app.

## Included
- Dashboard
- Detailed Estimate
- EB Materials
- PVC & GI Materials
- Sub Estimate
- Reports / totals
- Search
- Add, edit and delete estimate/material items
- Automatic amount calculation (quantity × rate)
- Local persistence on Android
- Reset to the original Excel-imported dataset

## Requirements
- Flutter 3.x
- Android Studio or Android SDK
- Android device/emulator

## Run
```bash
flutter pub get
flutter run
```

## Build APK
```bash
flutter build apk --release
```

APK will be created at:
`build/app/outputs/flutter-apk/app-release.apk`

## Notes
The original Excel workbook contains presentation/formula sheets (Detailed Estimate, Bill, Comparative Statement, Completion Report, specifications, EB, PVC & GI, Sub Estimate). This first production-ready mobile version converts the operational data into editable app records. The next enhancement can add exact print/PDF replicas of the Bill, Comparative Statement and Completion Report.
